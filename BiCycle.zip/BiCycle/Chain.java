public class Chain {
	private double price;
	private long model;
	private static Map<Date,Double> priceDetails = new HashMap<Date,Double>();
	private static Map<Long, HashMap<Date,Double>> chainDetails = new HashMap<Long, HashMap<Date,Double>>();

	public Chain(Long sModel, Double sPrice,int year, int month, int date){
		this.model = sModel;
		if(priceDetails != null && chainDetails != null)){
			Calender cal = Calender.getInstance();
			cal.set(year, month,date);
			priceDetails.put(cal,sPrice);
			chainDetails.put(sModel,priceDetails);
		}
	}

	public Double getPrice(int sModel){
		Double rate = 0;
		if(chainDetails.containsKey(sModel)){
			HashMap<Date,Double> temp  = chainDetails.getKey(sModel);
			rate= this.validatePrice(temp);
			System.out.println("The Price of Chain is" + rate);
		}
		return rate;
	}

	private Double validatePrice(Map priceStore){
		Double rate=0;
		SimpleDateFormat sdf = new SimplaDateFormat("yyyy-mm-dd");
		Date curr_date =sdf.parse(new Date());
		sdf.format(curr_date);
		if(priceStore != null){
			for(Map.Entry<Date,Double> entry = priceStore.entrySet();
			Date d = sdf.parse(entry.getKey());
			sdf.format(d);
			if(curr_date.compareTo(d) < 0 || curr_date.compareTo(d) == 0){
				rate = entry.getValue();
		}
		return rate;
	}
}