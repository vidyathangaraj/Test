public class Seat {
	private double price;
	private long model;
	private static Map<Date,Double> priceDetails = new HashMap<Date,Double>();
	private static Map<Long, HashMap<Date,Double>> seatDetails = new HashMap<Long, HashMap<Date,Double>>();

	
	public Seat(Long sModel, Double sPrice,int year, int month, int date){
		this.model = sModel;
		if(priceDetails != null && seatDetails != null)){
			Calender cal = Calender.getInstance();
			cal.set(year, month,date);
			priceDetails.put(cal,sPrice);
			seatDetails.put(sModel,priceDetails);
		}
	}
	
	public Long getModel()
	{
		return this.model;
	}
	public Double getPrice(int sModel,String inputDate){
		Double rate = 0;
		if(seatDetails.containsKey(sModel)){
			HashMap<Date,Double> temp  = seatDetails.get(sModel);
			rate= this.validatePrice(temp,inputDate);
			System.out.println("The Price of Seat is" + rate);
		}
		return rate;
	}

	private Double validatePrice(Map priceStore,String inputDate){
		Double rate=0;
		SimpleDateFormat sdf = new SimplaDateFormat("yyyy-mm-dd");
		Date curr_date =sdf.parse(inputDate);
		sdf.format(curr_date);
		if(priceStore != null){
			for(Map.Entry<Date,Double> entry = priceStore.entrySet()){
			Date d = sdf.parse(entry.getKey());
			sdf.format(d);
			if(curr_date.compareTo(d) < 0 || curr_date.compareTo(d) == 0){
				rate = entry.getValue();
			}
		}
		return rate;
	}
}