public class CycleDataProcess implements Runnable{
	protected BlockingQueue inputQueue = null;
	protected Map<String, String> inputValues = null;

	public class CycleDataProcess(BlockingQueue queue, Map value){
		inputQueue  = queue;
		inputValues = value;
	}
	public void run(){
		String value  = inputQueue.take();
		String DateOfPrice  = inputValues.get(value);
		BiCycle biCycleObj = new BiCycle();
		Double cyclePrice = biCycleObj.computePrice(biCycleObj,DateOfPrice);
		System.out.println("The Price of Bicycle is" + cyclePrice );
	}
}