public class BiCycle{
	private Seat seatObj;
	private Wheel frontWheel, backWheel;
	private Pedal pedalObj;
	private Chain chainObj;

	public BiCycle(){
		seatObj  = new Seat(Long model, Double price,int year, int month, int date );
		frontWheel  = new Wheel(Long model, Double price,int year, int month, int date );
		backWheel  = new Wheel(Long model, Double price,int year, int month, int date );
		pedalObj = new Pedal(Long model, Double price,int year, int month, int date );
		chainObj  = new Chain(Long model, Double price,int year, int month, int date );
	}
	private Seat getSeat(){
		retrun this.seatObj;
	}

	private Wheel getfrontWheel(){
		retrun this.frontWheel;
	}

	private Wheel getbackWheel(){
		retrun this.backWheel;
	}
	
	private Pedal getpedalObj(){
		retrun this.pedalObj;	}

	private Chain getchainObj(){
		retrun this.chainObj;
	}
	
	public double computePrice(BiCycle newCycle, String DateOfPricing){
		double totPrice = 0;
		if(quantity  > 0){
			totPrice = this.getPrice(newCycle,DateOfPricing) * quantity;
		}
		return totPrice;
	}

	private double  getPrice(BiCycle cycle,String DateOfPricing) {
		double price = cycle.getSeat().getPrice(cycle.getSeat().getModel(),DateOfPricing) +
				cycle.getfrontWheel().getPrice(cycle.getfrontWheel().getModel(),DateOfPricing) +
				cycle.getbackWheel().getPrice(cycle.getbackWheel().getModel(),DateOfPricing) +
				cycle.getpedalObj().getPrice(cycle.getpedalObj().getModel(),DateOfPricing) +
				cycle.getchainObj().getPrice(cycle.getchainObj().getModel(),DateOfPricing) ;
		return price;
	}


}