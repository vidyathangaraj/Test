public class Main(){
	public static final void main(String[] args){
		BlockingQueue dataQueue  = new ArrayBlockingQueue(1000);
		Map<String, String> inputData = new HashMap<String, String>();
		for(int val=0 ; val<args.length;val++){
			inputData.put(args[val],args[++val]);
		}
		CycleDAO obj = new CycleDAO(dataQueue,inputData);
		for(int count =0; count < 5; count++){
			Thread myThread = new Thread(CycleDAO);
			myThread.start();
		}
		for(int count =0; count < 5; count++){
			Thread dataProcessThread = new Thread(CycleDataProcess);
			dataProcessThread.start();
		}

		
	}
}