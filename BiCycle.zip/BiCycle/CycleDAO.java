public class CycleDAO implements Runnable{
	protected  BlockingQueue inputQueue = null;
	protected Map<String, String> inputValues = null;
	private int count = 0;
	public class CycleDAO(BlockingQueue queue, Map value){
		inputQueue  = queue;
		inputValues = value;
	}
	public void run(){
		for(Map.entry<String,String> val : inputValues.entrySet()){
			inputQueue.put(val.getKey());
		}
	}
}